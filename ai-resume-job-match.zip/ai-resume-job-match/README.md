
# AI Resume & Job Match Analyzer

**Future-relevant NLP project** that compares a resume with a job description and produces:
- Similarity score (TF‑IDF + Cosine Similarity)
- Skill extraction & gap analysis (using curated skills DB)
- Years-of-experience check (regex-based)
- JD key terms via TF‑IDF
- Clear, modern UI via **Streamlit**

## 🚀 Quick Start

```bash
# 1) Create & activate venv (recommended)
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2) Install requirements
pip install -r requirements.txt

# 3) Run the app
streamlit run app.py
```

Then open the local URL Streamlit prints (usually http://localhost:8501).

## 🧠 How it works

- **Preprocessing**: normalization of text; light stopword filtering
- **Similarity**: `TfidfVectorizer(ngram_range=(1,2))` + cosine similarity
- **Skills**: phrase-level exact matching using a curated list (`skills_db.json`); extend as needed
- **Experience**: regex over patterns like `"X years"`, `"X- Y years"`
- **Explainability**: show matched vs missing skills + top JD terms by TF‑IDF weight

## 📁 Project Structure

```
ai-resume-job-match/
├─ app.py
├─ matcher.py
├─ skills_db.json
├─ requirements.txt
├─ README.md
└─ samples/
   ├─ resume_sample.txt
   └─ jd_sample.txt
```

## 🧪 Try with Samples

- `samples/resume_sample.txt`
- `samples/jd_sample.txt`

## 🔧 Customization Ideas (for your presentation)

- Add spaCy NER to extract organizations/roles
- Use SentenceTransformers for semantic similarity
- Add PDF parsing fallback via `pypdf`
- Export a **PDF report** per analysis

## 📄 License

MIT
