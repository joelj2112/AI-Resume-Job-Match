
import re
import json
from pathlib import Path
from typing import List, Dict, Tuple
from dataclasses import dataclass

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

STOPWORDS = set("""a an and the or but if while with without upon onto into from to in on at by for of as is are was were be been being
this that these those there here it its it's themselves himself herself ourselves yourself yourselves i me my we our us you your they them their
he she his her which who whom whose what when where why how not no nor so than too very can could shall should will would may might must
""".split())

def normalize_text(s: str) -> str:
    s = s.lower()
    s = re.sub(r'[\u2010-\u2015]', '-', s)  # normalize dashes
    s = re.sub(r'[^a-z0-9\.\-\+/# ]+', ' ', s)  # drop non-alnum
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def tokenize(s: str) -> List[str]:
    return [t for t in re.split(r'\W+', s.lower()) if t and t not in STOPWORDS]

def load_skills(db_path: Path) -> List[str]:
    with open(db_path, 'r') as f:
        return json.load(f)

def extract_skills(text: str, skills: List[str]) -> List[str]:
    t = normalize_text(text)
    found = set()
    for sk in skills:
        # whole word / phrase match
        pattern = r'(?<![a-z0-9])' + re.escape(sk.lower()) + r'(?![a-z0-9])'
        if re.search(pattern, t):
            found.add(sk)
    return sorted(found)

def extract_years_experience(text: str) -> int:
    # Look for patterns like "X years", "X+ years", "over X years"
    text_l = text.lower()
    candidates = []
    for m in re.finditer(r'(\d+)\s*\+?\s*(?:years|yrs)', text_l):
        try:
            candidates.append(int(m.group(1)))
        except:
            pass
    # If resume mentions ranges like 3-5 years, capture the max
    for m in re.finditer(r'(\d+)\s*-\s*(\d+)\s*(?:years|yrs)', text_l):
        try:
            a, b = int(m.group(1)), int(m.group(2))
            candidates.append(max(a,b))
        except:
            pass
    return max(candidates) if candidates else 0

def top_keywords(texts: List[str], k: int = 15) -> List[Tuple[str, float]]:
    # extract top terms via TF-IDF
    vec = TfidfVectorizer(max_features=5000, ngram_range=(1,2))
    X = vec.fit_transform(texts)
    # Use the last doc as focus; get top tf-idf weights from it
    feature_names = np.array(vec.get_feature_names_out())
    last = X[-1].toarray()[0]
    idx = np.argsort(last)[::-1][:k]
    return [(feature_names[i], float(last[i])) for i in idx if last[i] > 0]

@dataclass
class MatchReport:
    similarity: float
    resume_skills: List[str]
    jd_skills: List[str]
    matched_skills: List[str]
    missing_skills: List[str]
    years_resume: int
    years_jd: int
    top_jd_terms: List[Tuple[str, float]]

def compute_similarity(resume_text: str, jd_text: str) -> float:
    vec = TfidfVectorizer(max_features=10000, ngram_range=(1,2))
    X = vec.fit_transform([resume_text, jd_text])
    sim = cosine_similarity(X[0], X[1])[0,0]
    return float(sim)

def analyze_match(resume_text: str, jd_text: str, skills_db_path: Path) -> MatchReport:
    skills = load_skills(skills_db_path)

    sim = compute_similarity(resume_text, jd_text)

    resume_sk = extract_skills(resume_text, skills)
    jd_sk = extract_skills(jd_text, skills)
    matched = sorted(set(resume_sk).intersection(jd_sk))
    missing = sorted(set(jd_sk) - set(resume_sk))

    yrs_res = extract_years_experience(resume_text)
    yrs_jd = extract_years_experience(jd_text)

    top_terms = top_keywords([resume_text, jd_text], k=15)

    return MatchReport(
        similarity = round(sim*100, 2),
        resume_skills = resume_sk,
        jd_skills = jd_sk,
        matched_skills = matched,
        missing_skills = missing,
        years_resume = yrs_res,
        years_jd = yrs_jd,
        top_jd_terms = top_terms
    )
