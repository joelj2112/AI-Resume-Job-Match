import streamlit as st
from sentence_transformers import SentenceTransformer, util
import spacy

# ----------------------
# Set page config
# ----------------------
st.set_page_config(
    page_title="AI Resume & Job Match Analyzer",
    page_icon="📊",
    layout="wide"
)

# ----------------------
# Load models
# ----------------------
@st.cache_resource
def load_model():
    return SentenceTransformer('all-MiniLM-L6-v2')

model = load_model()
nlp = spacy.load("en_core_web_sm")

# ----------------------
# Skill extraction
# ----------------------
def extract_skills(text):
    doc = nlp(text)
    skills = set()
    for chunk in doc.noun_chunks:
        if len(chunk.text) > 2:
            skills.add(chunk.text.strip().lower())
    for token in doc:
        if token.is_alpha and token.text[0].isupper():
            skills.add(token.text.strip().lower())
    return skills

# ----------------------
# Custom CSS for styling
# ----------------------
st.markdown("""
<style>
    .main-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #0a4c85;
        margin-bottom: 0.5rem;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .subtitle {
        font-size: 1.1rem;
        color: #444444;
        margin-bottom: 2rem;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .metrics-container {
        background-color: #f8f9fa;
        padding: 1.2rem 2rem;
        border-radius: 10px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.07);
        margin-bottom: 2.5rem;
    }
    .matched-skills {
        font-size: 1rem;
        color: #2c3e50;
        line-height: 1.5;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .footer-text {
        color: #6c757d;
        font-size: 0.9rem;
        margin-top: 3rem;
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
</style>
""", unsafe_allow_html=True)

# ----------------------
# Streamlit UI
# ----------------------
st.markdown('<h1 class="main-title">AI Resume & Job Match Analyzer</h1>', unsafe_allow_html=True)
st.markdown('<p class="subtitle">Paste your Resume and Job Description below to get a similarity and skill match analysis.</p>', unsafe_allow_html=True)

col1, col2 = st.columns([1, 1])
with col1:
    resume_input = st.text_area("Paste Resume", height=320, placeholder="Paste your resume text here...")
with col2:
    jd_input = st.text_area("Paste Job Description", height=320, placeholder="Paste the job description text here...")

st.write("")  # spacing for visual clarity

btn = st.button("Analyze Match")

if btn:
    if resume_input.strip() and jd_input.strip():
        emb_resume = model.encode(resume_input, convert_to_tensor=True)
        emb_jd = model.encode(jd_input, convert_to_tensor=True)
        semantic_score = float(util.cos_sim(emb_resume, emb_jd)) * 100
        resume_skills = extract_skills(resume_input)
        jd_skills = extract_skills(jd_input)
        overlap = resume_skills & jd_skills
        skill_overlap = (len(overlap) / len(jd_skills)) * 100 if jd_skills else 0
        final_score = (semantic_score * 0.7) + (skill_overlap * 0.3)

        st.markdown('<div class="metrics-container">', unsafe_allow_html=True)
        colA, colB, colC = st.columns(3)
        colA.metric(
            label="Semantic Similarity",
            value=f"{semantic_score:.2f}%",
            help="Semantic closeness between Resume and Job Description."
        )
        colB.metric(
            label="Skill Match",
            value=f"{skill_overlap:.2f}%",
            help="Percentage of Job Description skills found in the Resume."
        )
        colC.metric(
            label="Final Match Score",
            value=f"{final_score:.2f}%",
            help="Weighted overall match score combining semantics and skills."
        )
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('### Matched Skills')
        if overlap:
            st.markdown(f'<p class="matched-skills">{", ".join(sorted(overlap))}</p>', unsafe_allow_html=True)
        else:
            st.write("None")

        with st.expander("See All Detected Skills"):
            st.write(f"**Job Description Skills:** {', '.join(sorted(jd_skills)) if jd_skills else 'None'}")
            st.write(f"**Resume Skills:** {', '.join(sorted(resume_skills)) if resume_skills else 'None'}")
    else:
        st.error("Please paste both Resume and Job Description to proceed.")

st.markdown('<p class="footer-text">Developed with Python, Streamlit, Sentence Transformers, and spaCy</p>', unsafe_allow_html=True)
